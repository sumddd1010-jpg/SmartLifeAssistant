package com.smartlifeassistant

import android.app.BroadcastReceiver
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val message = intent.getStringExtra("message") ?: "Reminder"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("assistant_alerts", "Assistant alerts", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, "assistant_alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Smart Life Assistant")
                .setContentText(message)
                .setAutoCancel(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Smart Life Assistant")
                .setContentText(message)
                .setAutoCancel(true)
                .build()
        }
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
