package com.smartlifeassistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class GigNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName.lowercase()
        if (pkg.contains("zomato")) {
            val extras = sbn.notification.extras
            val title = extras.getCharSequence("android.title")?.toString().orEmpty()
            val body = extras.getCharSequence("android.text")?.toString().orEmpty()
            // Notification contents vary. Store/log only a basic event; user enters exact gig end time manually.
            Log.i("SmartLifeGig", "Zomato notification received: $title $body")
        }
    }
}
