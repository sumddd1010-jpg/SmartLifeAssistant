package com.smartlifeassistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    fun schedule(context: Context, atMillis: Long, message: String) {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("message", message)
        val pi = PendingIntent.getBroadcast(context, message.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
        } else alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pi)
    }
}
