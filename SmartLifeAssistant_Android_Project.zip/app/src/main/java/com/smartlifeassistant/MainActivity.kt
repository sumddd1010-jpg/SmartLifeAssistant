package com.smartlifeassistant

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var command: EditText
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        prefs = getSharedPreferences("assistant", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        root.addView(TextView(this).apply {
            text = "SMART LIFE ASSISTANT\nYour personal voice assistant"
            textSize = 24f
            setPadding(0, 0, 0, 20)
        })
        status = TextView(this).apply { textSize = 17f; setPadding(0, 8, 0, 12) }
        root.addView(status)
        updateStatus()
        button("Gig tracking settings") { openNotificationAccess() }
        button("Start / update current gig") { showGigDialog() }
        button("Battery settings") { showBatteryDialog() }
        button("Chat commands") { showChat() }
        button("Set alarm") { showAlarmDialog() }
        button("Settings / reset") { showSettingsDialog() }
        button("Screenshot") {
            AlertDialog.Builder(this).setTitle("Screenshot")
                .setMessage("Android-protected screens cannot be bypassed. Use your phone's normal screenshot controls only where the app permits capture.")
                .setPositiveButton("OK", null).show()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.UK
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "sla_voice")
    }

    private fun updateStatus() {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level", -1) ?: -1
        val threshold = prefs.getInt("battery_threshold", 25)
        val gigEnd = prefs.getLong("gig_end", 0L)
        val gigText = if (gigEnd > System.currentTimeMillis()) "Gig active until ${Date(gigEnd)}" else "No active gig entered"
        status.text = "Battery: ${if (level >= 0) "$level%" else "unknown"} (alert below $threshold%)\n$gigText\nGig notification access: check settings"
    }

    private fun openNotificationAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun showGigDialog() {
        val input = EditText(this).apply {
            hint = "Gig duration in minutes (e.g. 240)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this).setTitle("Enter current gig")
            .setMessage("Enter the remaining total gig duration in minutes. The app will say “Book gig now” 30 minutes before it ends.")
            .setView(input)
            .setPositiveButton("Start tracking") { _, _ ->
                val mins = input.text.toString().toLongOrNull()
                if (mins == null || mins < 31) {
                    Toast.makeText(this, "Enter at least 31 minutes", Toast.LENGTH_LONG).show()
                } else {
                    val end = System.currentTimeMillis() + mins * 60_000L
                    prefs.edit().putLong("gig_end", end).apply()
                    ReminderScheduler.schedule(this, end - 30 * 60_000L, "Book gig now")
                    updateStatus()
                    Toast.makeText(this, "Gig reminder scheduled", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showBatteryDialog() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("battery_threshold", 25).toString())
        }
        AlertDialog.Builder(this).setTitle("Battery alert threshold")
            .setMessage("Speak a warning when battery drops below this percentage.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value != null && value in 5..80) {
                    prefs.edit().putInt("battery_threshold", value).apply()
                    updateStatus()
                } else Toast.makeText(this, "Choose 5–80%", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showChat() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        command = EditText(this).apply { hint = "Type: check battery / gig status / book gig now" }
        box.addView(command)
        AlertDialog.Builder(this).setTitle("Chat assistant").setView(box)
            .setPositiveButton("Send") { _, _ -> handleCommand(command.text.toString()) }
            .setNeutralButton("Voice input") { _, _ ->
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    }
                    startActivityForResult(intent, 44)
                } catch (_: Exception) { speak("Voice recognition is not available on this phone.") }
            }.setNegativeButton("Close", null).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleCommand(phrase)
        }
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        val response = when {
            "battery" in c -> {
                val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                "Your battery is ${b?.getIntExtra("level", -1) ?: -1} percent."
            }
            "gig" in c && ("status" in c || "booked" in c) ->
                if (prefs.getLong("gig_end", 0L) > System.currentTimeMillis()) "A gig is being tracked." else "No active gig has been entered. Please check your Zomato app."
            "book gig" in c -> "Please book your next gig in the Zomato app."
            else -> "I can check battery, gig status, and help set alarms."
        }
        speak(response)
        AlertDialog.Builder(this).setMessage(response).setPositiveButton("OK", null).show()
    }

    private fun showAlarmDialog() {
        val input = EditText(this).apply {
            hint = "Minutes from now"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this).setTitle("Set alarm")
            .setMessage("Enter how many minutes from now.")
            .setView(input)
            .setPositiveButton("Set") { _, _ ->
                val mins = input.text.toString().toLongOrNull()
                if (mins != null && mins > 0) {
                    ReminderScheduler.schedule(this, System.currentTimeMillis() + mins * 60_000L, "Your alarm is ringing")
                    Toast.makeText(this, "Alarm set", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSettingsDialog() {
        AlertDialog.Builder(this).setTitle("Settings")
            .setItems(arrayOf("Notification access", "Reset all settings")) { _, which ->
                if (which == 0) openNotificationAccess()
                else AlertDialog.Builder(this).setMessage("Reset preferences and remove the tracked gig?")
                    .setPositiveButton("Reset") { _, _ -> prefs.edit().clear().apply(); updateStatus(); Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("Cancel", null).show()
            }.show()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
